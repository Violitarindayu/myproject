<?php include "header.php"; ?>
		
		<!-- Awal Page -->
		<div class="container">
		<!-- Awal baris -->
		<div class="row">
			<div class="col-md-12"><!-- Awal Kolom Pertama -->
			<div class="panel panel-default">
				<div class="panel-body">
				<h2 style="text-muted"><span class="glyphicon glyphicon-list"></span> Galeri</h2>
					<div class="row">
						<div class="col-md-4">
							<img src="images/perosotan.jpg" class="img-thumbnail img-responsive" width="80%">
						</div>
						<div class="col-md-4">
						<img src="images/bola.jpg" class="img-thumbnail img-responsive" height="40%">
						</div>
					</div>
					<div class="row">
						<div class="col-md-4">
							<img src="images/trampolin.jpg" class="img-rounded img-responsive">
						</div>
						<div class="col-md-4">
						<img src="images/ayunan.jpg" class="img-rounded img-responsive">
						</div>
					</div>
				</div>
			</div>

<?php include "header.php"; ?>