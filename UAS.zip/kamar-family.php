<?php include "header.php";?>


   <div class="container">
    <h1>Detail Kamar</h1>
    <div class="row">
      <div class="col-md-6">
        <img src="images/family.jpg" class="card-img-top" alt="">
        <p class="card-text">Kalau bepergian bersama dengan keluarga dengan anggota keluarga yang banyak atau teman-teman, kamar family room adalah pilihan yang tepat. Dari ukurannya, kamar ini jauh lebih luas dibandingkan kamar lainnya . Kamar hotel family room ini terdiri dari satu tempat tidur ukuran king size dan satu tempat tidur ukuran yang lebih kecil. Tentu saja, menambah tempat tidur juga bisa dilakukan
</p>



      </div>
      <div class="col-md-6">
        <h3>Family</h3>
        <p>Tipe Kamar:  Family Room</p>
        <p>Fasilitas</p>
        <ul>
        <li>Living Room</li>
        <li>Dapur Mini</li>
        <li>smart tV</li>
        <li>Bathub</li>
        <li>Wi-Fi, AC, TV, Mini-bar</li>
        <p>Harga per Malam: RP 1.200.000</p>
      </div>
    </div>
  </div>

<?php include "header.php";?>