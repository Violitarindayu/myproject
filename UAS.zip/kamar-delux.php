<?php include "header.php";?>

  <div class="container">
    <h1>Detail Kamar</h1>
    <div class="row">
      <div class="col-md-6">
        <img src="images/delux.jpg" class="card-img-top" alt="">
        <p class="card-text">Deluxe room adalah jenis kamar hotel diatas tipe standar dengan ukuran kamar yang lebih luas dan besar. Pada umumnya, deluxe room memiliki ukuran dan fasilitas lebih baik daripada superior room.

Superior room sendiri menawarkan ukuran ruangan yang lebih luas dan fasilitas yang hampir mirip dengan standard room. Bedanya pada jenis superior room, pengunjung bisa memilih kasur antara ukuran twin bed atau double bed.
      </div>
        <div class="col-md-6">
        <h3>MASTER HOTEL</h3>
        <p>Tipe Kamar: Deluxe Room</p>
        <h2>Fasilitas </h2>
        <ul>
        <li>Living Room</li>
        <li>Mini Bar</li>
        <li>smart tV</li>
        <li>Bathub</li>
        <li>Dapur Miini</li>
        <li>Meja Kerja</li>
        <li>Layanan Kamar 24 jam</li>
        <li> Wi-Fi, AC, TV, Mini-bar</li>
        <li>camilan seperti snack-snack, dan beberapa minuman soft drink yang telah tersedia secara gratis.</li>

    </ul>
        <p>Harga per Malam: RP 1.500.000</p>
      </div>
    </div>
  </div>

   <?php include "header.php";?>