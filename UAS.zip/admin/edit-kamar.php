<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php include "header.php"; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="proses-edit-kamar.php" method="POST">
                <?php
                $id=$_GET['id'];
                include "../koneksi.php";
                $tampil=$koneksi->query("select * from room where Id_kamar='$id'");
                $row=$tampil->fetch_assoc();
                ?>
                    <div class="form-group">
                        <label for="Nomor_Kamar">Nomor Kamar</label>
                        <input type="hidden" name="id_kamar" value="<?php echo $row['Id_kamar']?>" class="form-control">
                        <input type="number" name="Nomor_Kamar" value="<?php echo $row['Nomor_Kamar]?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="Type_Kamar">Type Kamar</label>
                        <select name="Type_Kamar" class="form-control">
                            <option value="Presidential">Presidential</option>
                            <option value="Delux">Delux</option>
                            <option value="Standart">Standart</option>
                            <option value="Singel">Singel</option>
                            <option value="Family">Family</option>
                            <option value="Junior">Junior Suite</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="Price_Permalam">Price Permalam</label>
                       <input type="number" name="Price_Permalam" value="<?php echo $row['Price_Permalam]?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="Status">Status</label>
                        <select name="Status" class="form-control">
                            <option value="<?php echo $row['Status']?>" selected><?php echo $row['Status']?></option>
                            <option value="Terisi">Terisi</option>
                            <option value="Tersedia">Tersedia</option>
                        </select>
                    </div>

                    <input type="submit" name="kirim" value="UBAH" class="btn btn-info">
                    <input type="reset" name="kosongkan" value="Kosongkan" class="btn btn-danger">
                </form>
            </div>
        </div>
    </div>

<?php include "footer.php";?>