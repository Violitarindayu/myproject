<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

$Nomor_Kamar=$_POST['Nomor_Kamar'];
$Type_Kamar=$_POST['Type_Kamar'];
$Price_Permalam=$_POST['Price_Permalam'];
$Status=$_POST['Status'];

include "../koneksi.php";

$simpan=$koneksi->query("insert into room (Nomor_Kamar,Type_Kamar,Price_Permalam,Status) 
                        values ('$Nomor_Kamar', '$Type_Kamar', '$Price_Permalam', '$Status')");
if($simpan==true){

    header("location:tampil-kamar.php?pesan=inputBerhasil");
} else{
    echo "Error";
}




?>