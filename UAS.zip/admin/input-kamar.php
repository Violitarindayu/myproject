<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php include "header.php";?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="proses-input-kamar.php" method="POST">
                    <div class="form-group">
                        <label for="Nomor_Kamar">Nomor Kamar</label>
                        <input type="number" name="Nomor_Kamar" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="Type_Kamar">Type_Kamar</label>
                        <select name="Type_Kamar" class="form-control">
                            <option value="Presidential">Presidential </option>
                            <option value="Delux">Delux</option>
                            <option value="Standart">Standart</option>
                            <option value="Singel">Singel</option>
                            <option value="Junior Suite">Junior Suite</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="Price_Permalam">Price_Permalam</label>
                        <input type="number" name="Price_Permalam" class="form-control">
                    </div>

                        <div class="form-group">
                       <label for="Status">Status</label>
                        <select name="Status" class="form-control">
                            <option value="Terisi">Terisi</option>
                            <option value="Tersedia">Tersedia</option>
                        </select>
                    </div>

                    <input type="submit" name="kirim" value="SIMPAN" class="btn btn-info">
                    <input type="reset" name="kosongkan" value="Kosongkan" class="btn btn-danger">
                </form>
            </div>
        </div>
    </div>
<?php include "footer.php";?>