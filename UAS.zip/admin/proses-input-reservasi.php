<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

$Nama_Tamu=$_POST['Nama_Tamu'];
$Tgl_Check_In=$_POST['Tgl_Check_In'];
$Tgl_Check_Out=$_POST['Tgl_Check_Out'];
$type_kamar=$_POST['Type_Kamar'];
$price_permalam=$_POST['Price_Permalam'];
$lama_inap=$_POST['Lama_Inap'];
$total_bayar=$_POST['Total_Bayar'];
$metode_bayar=$_POST['Metode_Bayar'];

include "../koneksi.php";

$simpan=$koneksi->query("insert into reservasi(Nama_Tamu,Tgl_Check_In, Tgl_Check_Out, Type_Kamar, Price_Permalam, Lama_Inap, Total_Bayar, Metode_Bayar) 
                        values ( '$Nama_Tamu', '$Tgl_Check_In', '$Tgl_Check_Out', '$type_kamar', '$price_permalam','$lama_inap', '$total_bayar','$metode_bayar')");

if($simpan==true){

    header("location:tampil-reservasi.php?pesan=inputBerhasil");
} else{
    echo "Error";
}




?>