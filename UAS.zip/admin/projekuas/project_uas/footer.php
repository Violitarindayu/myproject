<!-- FOOTER -->
		<div class="container-fluid">
		<div class="row">
			<div class="col-md-4">
			<h3><span class="glyphicon glyphicon-bullhorn"></span> Berita Terbaru</h3>
				<ul class="list-group">
					<li class="list-group-item"><a href="#">Beasiswa melanjut kuliah luar negeri</a></li>
					<li class="list-group-item"><a href="#">Tahun 2018 Mahasiswa harus publikasi karya ilmiah</a></li>
					<li class="list-group-item"><a href="#">Menristekdikti akan rutin engunjungi kampus swasta setiap minggu</a></li>
				</ul>
				
			</div>
			<div class="col-md-4">
			<h3><span class="glyphicon glyphicon-info-sign"></span> Informasi Akademik</h3>
				<ul class="list-group">
					<li class="list-group-item"><a href="#">Ujian Akhir Semester(UAS) 2018 dimulai bulan Maret</a></li>
					<li class="list-group-item"><a href="#">Mahasiswa diwajibkan memakai jas Almamater setiap hari senin</a></li>
					<li class="list-group-item"><a href="#">Upacara hari pendidikan Nasional di lapangan kampus</a></li>
				</ul>
				
			</div>
			<div class="col-md-4">
			<h3><span class="glyphicon glyphicon-link"></span> Link Terkait</h3>
				<ul class="list-group">
					<li class="list-group-item"><a href="#">Penerimaan Mahasiswa Baru</a></li>
					<li class="list-group-item"><a href="#">Jurnal Ilmiah</a></li>
					<li class="list-group-item"><a href="#">Sistem Informasi Akademik</a></li>
					<li class="list-group-item"><a href="#">Sistem Informasi Almuni</a></li>
				</ul>
				
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-12">
				<center>Copyright &copy 2018 Website Institut Teknologi dan Bisnis Indonesia, design with <span class="glyphicon glyphicon-heart"></span> by Roberto Kaban<br/>
				<a href="index.php">Home </a> | 
				<a href="about.php">About Us </a> | 
				<a href="contact.php">Contact Us </a> |
				<a href="login.php">Login </a><br/><br/>
				<label class="label label-danger">PERHATIAN:</label>
				Semua informasi di halaman ini memiliki hak cipta, anda tidak diperkenankan untuk menyebarluaskan tanpa seijin pengelola website
				</center>
			</div>
			</div>
	</div><!-- Akhir FOOTER -->
		
	<script src="bootstrap/js/jquery.min.js"></script>
	<script src="bootstrap/js/bootstrap.min.js"></script>
	<script src="bootstrap/js/dataTables.bootstrap.min.js"></script>
	<script src="bootstrap/js/jquery.dataTables.js"></script>
	<script src="bootstrap/js/scripts.js"></script>
	</body>
</html>