<?php include "header.php";?>

<div class="container">
    <h1>Detail Kamar</h1>
    <div class="row">
      <div class="col-md-6">
        <img src="President.jpg" class="card-img-top" alt=" president Room ">
        <p class="card-text">President Suite merupakan unit kamar terbaik yang dihadirkan, mulai dari ukuran ruangan lebih luas dari unit lain yang terdiri dari dua kamar tidur, living room, dapur, dan mini bar hingga kemewahan eksklusif yang memadukan desain interior bergaya eropa modern. Cocok bagi Anda yang menginginkan kamar dan ruangan mewah saat berlibur bersama keluarga. Untuk memberikan kenyamanan saat beraktivitas, kamar ini dilengkapi dengan beragam furniture modern, sofa, kursi, meja, LED TV, pendingin ruangan (AC), akses wifi, kamar mandi modern,
</p>



      </div>
      <div class="col-md-6">
        <h3>Violita Hotel</h3>
        <p>Tipe Kamar: Presidential Room</p>
        <h2>Fasilitas </h2>
        <ul>
        <li>Living Room</li>
        <li>Dapur Mini</li>
        <li>layanan kamar 24 jam</li>
        <li>Bathub</li>
        <li>Meja Kerja</li>
        <li>Dining area</li>
        <li>Kunci kamar elektronik</li>
        <li>Kolam Renang Outdoor</li>
        <li>Pusat Kebugaran</li>
        <li>Pusat Layanan Bisnis</li>
        <li>Layanan telepon sambungan langsung internasional</li>
        <li>Kotak penyimpanan di kamar</li>
        <li>Pembuat kopi atau teh</li>
        <li>Mini bar</li>
        <li>Meja setrika</li>
       <li> Wi-Fi, AC, TV, Mini-bar</li>

    </ul>
        <p>Harga per Malam: RP 3.900.000</p>
      </div>
    </div>
  </div>

  <?php include "header.php";?>
