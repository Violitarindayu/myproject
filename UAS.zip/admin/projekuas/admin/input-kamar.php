<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php include "header.php";?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="proses-input-kamar.php" method="POST">
                    <div class="form-group">
                        <label for="Nomor_Kamar">Nomor Kamar</label>
                        <input type="number" name="Nomor_Kamar" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="Type_Kamar">Type_Kamar</label>
                        <input type="text" name="Type_Kamar" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="Price_Permalam">Price_Permalam</label>
                        <input type="number" name="Price_Permalam" class="form-control">
                    </div>
                       <label for="Price_Permalam">Status</label>
                        <textarea name="Status" class="form-control"></textarea>
                    </div>

                    <input type="submit" name="kirim" value="SIMPAN" class="btn btn-info">
                    <input type="reset" name="kosongkan" value="Kosongkan" class="btn btn-danger">
                </form>
            </div>
        </div>
    </div>
<?php include "footer.php";?>