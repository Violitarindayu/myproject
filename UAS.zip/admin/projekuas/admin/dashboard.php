		<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
					<div class="jumbotron">
						<h2>BEASISWA SAMPAI TAMAT SARJANA</h2>
						<p>Sebagai bentuk bakti yayasan poliprofesi kepada pendidikan indonesia, maka setiap tahunnya yayasan memberikan beasiswa kuliah gratis hingga tamat kepada mahasiswa Diploma III(D3). </p>
						<p><a class="btn btn-warning btn-lg" href="beasiswa_d3.php" role="button">Selengkapnya</a>
						<a class="btn btn-danger btn-lg" href="daftar_beasiswa.php"role="button">Daftar</a></p>
				</div>
      </div>
		</div>
		</div><!-- Akhir Jumbotron -->