<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

$Nama_Tamu=$_POST['Nama_Tamu'];
$tanggal_lahir=$_POST['Tanggal_Lahir'];
$Jenis_Kelamin=$_POST['Jenis_Kelamin'];
$alamat=$_POST['Alamat'];
$no_telpon=$_POST['No_Telpon'];

include "../koneksi.php";

$simpan=$koneksi->query("insert into tamu(Nama_Tamu,Tanggal_Lahir,Jenis_Kelamin,Alamat, No_Telpon) 
                        values ('$Nama_Tamu', '$tanggal_lahir', '$Jenis_Kelamin', '$alamat', '$no_telpon')");

if($simpan==true){

    header("location:tampil-tamu.php?pesan=inputBerhasil");
} else{
    echo "Error";
}




?>