<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

include "../koneksi.php";

$id_room=$_POST['Id_room'];
$type_kamar=$_POST['type_kamar'];
$fasilitas=$_POST['fasilitas'];
$deskripsi=$_POST['deskripsi'];
$price_permalam=$_POST['Price_Permalam'];

$ubah=$koneksi->query("update standart set type_kamar='$type_kamar', fasilitas='$fasilitas', deskripsi='$deskripsi', Price_Permalam='$price_permalam', where Id_room='$id'");

if($ubah==true){

    header("location:tampil-standart.php?pesan=editBerhasil");
} else{
    echo "Error";
}

?>