<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php include "header.php"; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="proses-edit-delux.php" method="POST">
                <?php
                $id=$_GET['id'];
                include "../koneksi.php";
                $tampil=$koneksi->query("select * from delux where Id_room='$id'");
                $row=$tampil->fetch_assoc();
                ?>
                    <div class="form-group">
                        <label for="type_kamar">Type_Kamar</label>
                        <input type="hidden" name="Id_room" value="<?php echo $row['Id_room']?>" class="form-control">
                        <input type="text" name="type_kamar" value="<?php echo $row['type_kamar]?>" class="form-control">
                    </div>

                      <div class="form-group">
                        <label for="fasilitas">Fasilitas</label>
                        <input type="text" name="fasilitas" value="<?php echo $row['fasilitas]?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="deskripsi">Deskripsi</label>
                        <input type="text" name="deskripsi" value="<?php echo $row['deskripsi?>" class="form-control">
                    </div>


                     <div class="form-group">
                        <label for="Price_Permalam">Price Permalam</label>
                        <input type="number" name="Price_Permalam" value="<?php echo $row['Price_Permalam]?>" class="form-control">
                    </div>

                    <input type="submit" name="kirim" value="UBAH" class="btn btn-info">
                    <input type="reset" name="kosongkan" value="Kosongkan" class="btn btn-danger">
                </form>
            </div>
        </div>
    </div>

<?php include "footer.php";?>