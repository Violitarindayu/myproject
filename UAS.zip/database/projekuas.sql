-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 22 Feb 2024 pada 05.51
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projekuas`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `delux`
--

CREATE TABLE `delux` (
  `Id_room` int(11) NOT NULL,
  `type_kamar` varchar(50) NOT NULL,
  `fasilitas` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `Price_Permalam` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `delux`
--

INSERT INTO `delux` (`Id_room`, `type_kamar`, `fasilitas`, `deskripsi`, `Price_Permalam`) VALUES
(1, 'Delux Room', 'Living Room\r\nMini Bar\r\nsmart tV\r\nBathub\r\nDapur Miini\r\nMeja Kerja\r\nLayanan Kamar 24 jam\r\nWi-Fi, AC, TV, Mini-bar', 'Deluxe room adalah jenis kamar hotel diatas tipe standar dengan ukuran kamar yang lebih luas dan besar. Pada umumnya, deluxe room memiliki ukuran dan fasilitas lebih baik daripada superior room. Superior room sendiri menawarkan ukuran ruangan yang lebih luas dan fasilitas yang hampir mirip dengan standard room. Bedanya pada jenis superior room, pengunjung bisa memilih kasur antara ukuran twin bed atau double bed.', 'RP 1.500.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_reservasi`
--

CREATE TABLE `detail_reservasi` (
  `Id_Detail_Reservasi` int(5) NOT NULL,
  `Id_Reservasi` int(5) NOT NULL,
  `Id_kamar` int(5) NOT NULL,
  `No_Kamar` enum('101','102','201','202','203','301','302','303','401','402','403','501','501','601','602') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `family`
--

CREATE TABLE `family` (
  `Id_room` int(11) NOT NULL,
  `type_kamar` varchar(50) NOT NULL,
  `fasilitas` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `Price_Permalam` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `family`
--

INSERT INTO `family` (`Id_room`, `type_kamar`, `fasilitas`, `deskripsi`, `Price_Permalam`) VALUES
(1, 'Family Room', 'Living Room\r\nDapur Mini\r\nsmart tV\r\nBathub\r\nWi-Fi, AC, TV, Mini-bar\r\n', 'Kalau bepergian bersama dengan keluarga dengan anggota keluarga yang banyak atau teman-teman, kamar family room adalah pilihan yang tepat. Dari ukurannya, kamar ini jauh lebih luas dibandingkan kamar lainnya . Kamar hotel family room ini terdiri dari satu tempat tidur ukuran king size dan satu tempat tidur ukuran yang lebih kecil. Tentu saja, menambah tempat tidur juga bisa dilakukan.', 'RP 1.200.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `junior`
--

CREATE TABLE `junior` (
  `Id_room` int(11) NOT NULL,
  `type_kamar` varchar(50) NOT NULL,
  `fasilitas` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `Price_Permalam` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `junior`
--

INSERT INTO `junior` (`Id_room`, `type_kamar`, `fasilitas`, `deskripsi`, `Price_Permalam`) VALUES
(1, 'Junior Suite Room', 'Living Room\r\nMini Bar\r\nsmart tV\r\nBathub\r\nDapur Mini\r\nMeja Kerja\r\nLayanan Kamar 24 jam\r\nWi-Fi, AC, TV, Mini-bar', 'Junior suite room merupakan kamar hotel yang dirancang untuk para tamu yang ingin merileksasikan diri. Yakni dengan cara menikmati pemandangan alam, sambil bersantai di kamar hotel yang nyaman, serta diterangi oleh cahaya alami. Wajar saja jika junior suite room menjadi primadona untuk para traveler. Dengan ukuran ruang yang cukup luas, Junior suite mampu memberikan tempat perlindungan yang nyaman dan damai. Interior yang diberikan menciptakan suasana berlibur layaknya di rumah sendiri. Wajar saja jika setiap tamu dipastikan mendapatkan pengalaman menginap yang nyaman. Tipe junior suite room memang agak beda dengan tipe deluxe. Lebar kamarnya lebih luas dan didalamnya juga terdapat fasilitas lebih. Seperti Smart TV, koneksi internet kecepatan tinggi, camilan seperti snack-snack, dan beberapa minuman soft drink yang telah tersedia secara gratis.', 'Rp 1.250.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `Id_Kategori` int(11) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `Keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`Id_Kategori`, `Nama`, `Keterangan`) VALUES
(1, 'Presidential Room', 'Kamar Presidential'),
(2, 'Delux Room', 'Kamar Delux');

-- --------------------------------------------------------

--
-- Struktur dari tabel `komentar`
--

CREATE TABLE `komentar` (
  `komentar_id` int(5) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pesan` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `komentar`
--

INSERT INTO `komentar` (`komentar_id`, `nama`, `email`, `pesan`, `date`) VALUES
(0, 'violita', 'rindayulita175@gmail.com', ' semoga kedepannya lebih baik', '2024-02-21 07:11:45');

-- --------------------------------------------------------

--
-- Struktur dari tabel `presidential`
--

CREATE TABLE `presidential` (
  `Id_room` int(11) NOT NULL,
  `type_kamar` varchar(50) NOT NULL,
  `fasilitas` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `Price_Permalam` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `presidential`
--

INSERT INTO `presidential` (`Id_room`, `type_kamar`, `fasilitas`, `deskripsi`, `Price_Permalam`) VALUES
(1, 'Presidential Room', 'Living Room,Dapur Mini,layanan kamar 24 jam,Bathub,Meja Kerja,Kunci kamar elektronik, Kolam Renang Outdoor,Layanan telepon sambungan langsung internasional,Kotak penyimpanan di kamar, Mesin pembuat kopi.', 'President Suite merupakan unit kamar terbaik yang dihadirkan, mulai dari ukuran ruangan lebih luas dari unit lain yang terdiri dari dua kamar tidur, living room, dapur, dan mini bar hingga kemewahan eksklusif yang memadukan desain interior bergaya eropa modern. Cocok bagi Anda yang menginginkan kamar dan ruangan mewah saat berlibur bersama keluarga. Untuk memberikan kenyamanan saat beraktivitas, kamar ini dilengkapi dengan beragam furniture modern, sofa, kursi, meja, LED TV, pendingin ruangan (AC), akses wifi, kamar mandi modern', 'Rp 2.000.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `reservasi`
--

CREATE TABLE `reservasi` (
  `Id_Reservasi` int(5) NOT NULL,
  `Id_Tamu` int(5) NOT NULL,
  `Nama_Tamu` varchar(255) NOT NULL,
  `Tgl_Check_In` date NOT NULL,
  `Tgl_Check_Out` date NOT NULL,
  `Type_Kamar` enum('Presidential Room','Delux Room','Singgel Room','Standart Room','Junior Suite Room','Family Room') NOT NULL,
  `Price_Permalam` varchar(50) NOT NULL,
  `Lama_Inap` enum('1','2','3','4') NOT NULL,
  `Total_Bayar` varchar(50) NOT NULL,
  `Metode_Bayar` enum('Cash','Debit','Kredit','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `reservasi`
--

INSERT INTO `reservasi` (`Id_Reservasi`, `Id_Tamu`, `Nama_Tamu`, `Tgl_Check_In`, `Tgl_Check_Out`, `Type_Kamar`, `Price_Permalam`, `Lama_Inap`, `Total_Bayar`, `Metode_Bayar`) VALUES
(17, 133, 'JustinaM', '2024-02-09', '2024-02-10', 'Presidential Room', '2000000', '1', '2000000', 'Cash'),
(21, 0, 'SaniaNainggolan', '2024-02-14', '0000-00-00', 'Delux Room', '1100000', '1', '1100000', 'Cash'),
(22, 123, 'Den Ayu', '2024-02-18', '2024-02-19', 'Presidential Room', '20000000', '1', '2000000', 'Debit'),
(25, 54433455, 'siska', '2024-02-09', '2024-02-12', 'Junior Suite Room', 'Rp.1.250.000', '3', '3750000', 'Cash');

-- --------------------------------------------------------

--
-- Struktur dari tabel `restoran`
--

CREATE TABLE `restoran` (
  `Id_Menu` int(11) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `Deskripsi` text NOT NULL,
  `Category` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `restoran`
--

INSERT INTO `restoran` (`Id_Menu`, `Nama`, `Deskripsi`, `Category`) VALUES
(1, 'OPOR AYAM', 'Opor ayam adalah masakan Indonesia yang terbuat dari potongan ayam yang dimasak dalam kuah kental berbahan dasar santan kelapa, dengan tambahan rempah-rempah seperti ketumbar, kunyit, dan serai', 'makanan'),
(2, 'PECAL', 'Pecal adalah hidangan khas Indonesia yang terdiri dari sayuran segar seperti kacang panjang, tauge, kentang, dan tahu yang disajikan dengan saus kacang yang lezat. Sausnya biasanya terbuat dari kacang tanah yang dihaluskan, dicampur dengan bumbu-bumbu seperti petis, gula, garam, dan air jeruk nipis. Pecal sering dihidangkan bersama lontong atau nasi, menciptakan kombinasi rasa yang gurih, pedas, dan segar.', 'makanan'),
(3, 'AYAM LENGKUAS', 'Ayam lengkuas adalah hidangan kuliner yang menggunakan lengkuas sebagai bahan utama pada saus atau bumbu. Lengkuas memberikan aroma khas dan rasa yang unik pada ayam, menciptakan kombinasi cita rasa yang lezat dan menggugah selera.', 'makanan'),
(4, 'SOTO', 'Soto adalah hidangan sup khas Indonesia yang berisi daging, sayuran, dan bihun, disajikan dengan kuah kaldu yang kaya rempah seperti serai, daun jeruk, dan bumbu lainnya.', 'makanan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `room`
--

CREATE TABLE `room` (
  `Id_kamar` int(11) NOT NULL,
  `Nomor_Kamar` int(50) NOT NULL,
  `Type_Kamar` varchar(50) NOT NULL,
  `Price_Permalam` varchar(50) NOT NULL,
  `Status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `room`
--

INSERT INTO `room` (`Id_kamar`, `Nomor_Kamar`, `Type_Kamar`, `Price_Permalam`, `Status`) VALUES
(1, 101, 'Presidential', '2000000', 'Tersedia'),
(2, 102, 'Presidential', '2000000', 'Tersedia'),
(4, 201, 'Delux', '1500000', 'Tersedia'),
(5, 202, 'Delux', '1500000', 'Tersedia'),
(6, 203, 'Delux', '1500000', 'Tersedia'),
(7, 301, 'Junior Suite ', '1250000', 'Tersedia'),
(8, 302, 'Junior Suite', '1250000', 'Tersedia'),
(9, 303, 'Junior Suite ', '1250000', 'Tersedia'),
(10, 401, 'Singgel', '1000000', 'Tersedia'),
(11, 402, 'Singgel', '1000000', 'Tersedia'),
(12, 403, 'Singgel', '1000000', 'Tersedia'),
(13, 501, 'Standart', '1100000', 'Tersedia'),
(14, 502, 'Standart', '1100000', 'Tersedia'),
(15, 601, 'Family', '1200000', 'Tersedia'),
(16, 602, 'Family', '1200000', 'Tersedia');

-- --------------------------------------------------------

--
-- Struktur dari tabel `room standart`
--

CREATE TABLE `room standart` (
  `Id_room` int(11) NOT NULL,
  `type_kamar` varchar(50) NOT NULL,
  `fasilitas` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `Price_Permalam` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `room standart`
--

INSERT INTO `room standart` (`Id_room`, `type_kamar`, `fasilitas`, `deskripsi`, `Price_Permalam`) VALUES
(1, 'Standart Room', 'Living Room\r\nDapur Mini>\r\nsmart tV\r\nBathub\r\nWi-Fi, AC, TV, Mini-bar', 'Standard room merupakan tipe kamar terbawah yang ada di hotel. Biasanya di tipe kamar ini hanya terdapat satu single bed saja dengan fasilitas standar, seperti televisi, AC, telepon, toiletteries, kopi, dan teh.\r\n\r\nUkuran tempat tidur bisa berbeda antara satu hotel dengan hotel lainnya. Ada hotel dengan single bed ada juga yang menyediakan kasur berukuran queen size atau bahkan king size. Kamar ini juga biasanya terletak di lantai paling bawah hotel.\r\n\r\nUntuk ukuran harga, kamar ini merupakan kamar termurah dibandingkan tipe kamar lainnya. Namun ada pula hotel yang tidak menyediakan kamar tipe ini.', 'Rp 1.100.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `singgel`
--

CREATE TABLE `singgel` (
  `Id_room` int(11) NOT NULL,
  `type_kamar` varchar(50) NOT NULL,
  `fasilitas` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `Price_Permalam` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `singgel`
--

INSERT INTO `singgel` (`Id_room`, `type_kamar`, `fasilitas`, `deskripsi`, `Price_Permalam`) VALUES
(1, 'Singel Room', 'Living Room Mini Bar smart tV Bathub Meja Kerja Wi-Fi, AC, TV, Mini-bar', 'Single room atau single studio room adalah jenis kamar hotel yang umum dimiliki setiap hotel. Single room biasanya hanya terdiri dari satu ruangan yang berisi hanya satu tempat tidur, sofa, dan kamar mandi. Jenis kamar hotel single room cocok satu orang saja karena memang fasilitas dan kapasitas yang tidak besar.', 'Rp 1.000.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `standart`
--

CREATE TABLE `standart` (
  `Id_room` int(11) NOT NULL,
  `type_kamar` varchar(50) NOT NULL,
  `fasilitas` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `Price_Permalam` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `standart`
--

INSERT INTO `standart` (`Id_room`, `type_kamar`, `fasilitas`, `deskripsi`, `Price_Permalam`) VALUES
(1, 'Standart Room', 'Living Room\r\nDapur Mini>\r\nsmart tV\r\nBathub\r\nWi-Fi, AC, TV, Mini-bar\r\n', 'Standard room merupakan tipe kamar terbawah yang ada di hotel. Biasanya di tipe kamar ini hanya terdapat satu single bed saja dengan fasilitas standar, seperti televisi, AC, telepon, toiletteries, kopi, dan teh.\r\n\r\nUkuran tempat tidur bisa berbeda antara satu hotel dengan hotel lainnya. Ada hotel dengan single bed ada juga yang menyediakan kasur berukuran queen size atau bahkan king size. Kamar ini juga biasanya terletak di lantai paling bawah hotel.\r\n\r\nUntuk ukuran harga, kamar ini merupakan kamar termurah dibandingkan tipe kamar lainnya. Namun ada pula hotel yang tidak menyediakan kamar tipe ini.', 'RP 1.100.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tamu`
--

CREATE TABLE `tamu` (
  `Id_Tamu` int(11) NOT NULL,
  `Nama_Tamu` varchar(50) NOT NULL,
  `Tanggal_Lahir` date NOT NULL,
  `Jenis_Kelamin` varchar(25) NOT NULL,
  `Alamat` text NOT NULL,
  `No_Telpon` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tamu`
--

INSERT INTO `tamu` (`Id_Tamu`, `Nama_Tamu`, `Tanggal_Lahir`, `Jenis_Kelamin`, `Alamat`, `No_Telpon`) VALUES
(1, 'Erni Puspita', '1999-08-21', 'Wanita', 'jalan suka suka , kota indah', '082272088134'),
(2, 'Riko Mahendra ', '1997-07-21', 'Pria', 'jalan nuasa , kota Medan', '087654321110'),
(3, 'Bila Aulia', '1996-12-25', 'Wanita', 'perumahan seisuka Asahan', '085371222020'),
(4, 'Mitra Aditya', '2000-08-21', 'Pria', 'jalan pembangunan, Medan', '085134252520'),
(12, 'violita', '2024-04-12', 'Wanita', 'medan sunggal', '0812648735'),
(13, 'SaniaNainggolan', '2001-01-21', 'Wanita', 'Medan Baru', '09876545666777');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(254) NOT NULL,
  `email` varchar(50) NOT NULL,
  `token` char(128) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `last_login` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `email`, `token`, `status`, `last_login`) VALUES
(1, 'vio', '87bc4f03a3b16933e98ae9961d6a6a8d', 'rindayulita@gmail.com', 'ae63bf1a012daa975e1ccc264d19beea', '1', '2024-02-22 11:49:54');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `delux`
--
ALTER TABLE `delux`
  ADD PRIMARY KEY (`Id_room`);

--
-- Indeks untuk tabel `detail_reservasi`
--
ALTER TABLE `detail_reservasi`
  ADD PRIMARY KEY (`Id_Detail_Reservasi`),
  ADD KEY `fk_reservasi` (`Id_Reservasi`),
  ADD KEY `fk_room` (`Id_kamar`);

--
-- Indeks untuk tabel `family`
--
ALTER TABLE `family`
  ADD PRIMARY KEY (`Id_room`);

--
-- Indeks untuk tabel `junior`
--
ALTER TABLE `junior`
  ADD PRIMARY KEY (`Id_room`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`Id_Kategori`);

--
-- Indeks untuk tabel `presidential`
--
ALTER TABLE `presidential`
  ADD PRIMARY KEY (`Id_room`);

--
-- Indeks untuk tabel `reservasi`
--
ALTER TABLE `reservasi`
  ADD PRIMARY KEY (`Id_Reservasi`),
  ADD KEY `fk_tamu` (`Id_Tamu`);

--
-- Indeks untuk tabel `restoran`
--
ALTER TABLE `restoran`
  ADD PRIMARY KEY (`Id_Menu`);

--
-- Indeks untuk tabel `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`Id_kamar`);

--
-- Indeks untuk tabel `room standart`
--
ALTER TABLE `room standart`
  ADD PRIMARY KEY (`Id_room`);

--
-- Indeks untuk tabel `singgel`
--
ALTER TABLE `singgel`
  ADD PRIMARY KEY (`Id_room`);

--
-- Indeks untuk tabel `standart`
--
ALTER TABLE `standart`
  ADD PRIMARY KEY (`Id_room`);

--
-- Indeks untuk tabel `tamu`
--
ALTER TABLE `tamu`
  ADD PRIMARY KEY (`Id_Tamu`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `delux`
--
ALTER TABLE `delux`
  MODIFY `Id_room` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `detail_reservasi`
--
ALTER TABLE `detail_reservasi`
  MODIFY `Id_Detail_Reservasi` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `family`
--
ALTER TABLE `family`
  MODIFY `Id_room` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `junior`
--
ALTER TABLE `junior`
  MODIFY `Id_room` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `Id_Kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `presidential`
--
ALTER TABLE `presidential`
  MODIFY `Id_room` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `reservasi`
--
ALTER TABLE `reservasi`
  MODIFY `Id_Reservasi` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT untuk tabel `restoran`
--
ALTER TABLE `restoran`
  MODIFY `Id_Menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT untuk tabel `room`
--
ALTER TABLE `room`
  MODIFY `Id_kamar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `room standart`
--
ALTER TABLE `room standart`
  MODIFY `Id_room` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `singgel`
--
ALTER TABLE `singgel`
  MODIFY `Id_room` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `standart`
--
ALTER TABLE `standart`
  MODIFY `Id_room` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tamu`
--
ALTER TABLE `tamu`
  MODIFY `Id_Tamu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `detail_reservasi`
--
ALTER TABLE `detail_reservasi`
  ADD CONSTRAINT `fk_reservasi` FOREIGN KEY (`Id_Reservasi`) REFERENCES `reservasi` (`Id_Reservasi`),
  ADD CONSTRAINT `fk_room` FOREIGN KEY (`Id_kamar`) REFERENCES `room` (`Id_kamar`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
