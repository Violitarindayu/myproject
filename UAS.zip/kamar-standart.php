<?php include "header.php";?>

<div class="container">
    <h1>Detail Kamar</h1>
    <div class="row">
      <div class="col-md-6">
        <img src="images/standart.jpg" class="card-img-top" alt="">
        <p class="card-text">
</p>

      </div>
      <div class="col-md-6">
        <h3>MASTER HOTEL</h3>
        <p>Tipe Kamar: StandarT Room</p>
        <p>Fasilitas</p>
        <ul>
        <li>Living Room</li>
        <li>Dapur Mini></li>
        <li>smart tV</li>
        <li>Bathub</li>
        <li> Wi-Fi, AC, TV, Mini-bar</li>
      
        <p>Harga per Malam: RP 1.100.000</p>
      </div>
    </div>
  </div>

  <?php include "header.php";?>