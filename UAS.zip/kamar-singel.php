<?php include "header.php";?>

  <div class="container">
    <h1>Detail Kamar</h1>
    <div class="row">
      <div class="col-md-6">
        <img src="images/sinngel.jpg" class="card-img-top" alt="">
        <p class="card-text">Single room atau single studio room adalah jenis kamar hotel yang umum dimiliki setiap hotel. Single room biasanya hanya terdiri dari satu ruangan yang berisi hanya satu tempat tidur, sofa, dan kamar mandi. Jenis kamar hotel single room cocok satu orang saja karena memang fasilitas dan kapasitas yang tidak besar.
</p>

      </div>
      <div class="col-md-6">
        <h3>MASTER HOTEL</h3>
        <p>Tipe Kamar:Single Room</p>
        <p>Fasilitas</p>
        <ul>
        <li>Living Room</li>
        <li>Mini Bar</li>
        <li>smart tV</li>
        <li>Bathub</li>
        <li>Meja Kerja</li>
        <li> Wi-Fi, AC, TV, Mini-bar</li>
        <p>Harga per Malam: RP 1.000.000</p>
      </div>
    </div>
  </div>

  <?php include "header.php";?>