<?php include "header.php";?>

  <div class="container">
    <h1>Detail Kamar</h1>
    <div class="row">
      <div class="col-md-6">
        <img src="images/junior.jpg" class="card-img-top" alt="">
        <p class="card-text">Junior suite room merupakan kamar hotel yang dirancang untuk para tamu yang ingin merileksasikan diri. Yakni dengan cara menikmati pemandangan alam, sambil bersantai di kamar hotel yang nyaman, serta diterangi oleh cahaya alami. Wajar saja jika junior suite room menjadi primadona untuk para traveler.

Dengan ukuran ruang yang cukup luas, Junior suite mampu memberikan tempat perlindungan yang nyaman dan damai. Interior yang diberikan menciptakan suasana berlibur layaknya di rumah sendiri. Wajar saja jika setiap tamu dipastikan mendapatkan pengalaman menginap yang nyaman.

Tipe junior suite room memang agak beda dengan tipe deluxe. Lebar kamarnya lebih luas dan didalamnya juga terdapat fasilitas lebih. Seperti Smart TV, koneksi internet kecepatan tinggi, camilan seperti snack-snack, dan beberapa minuman soft drink yang telah tersedia secara gratis.
</p>
      </div>
  <div class="col-md-6">
        <h3>MASTER HOTEL</h3>
        <p>Tipe Kamar: Junior Suite Room</p>
        <h2>Fasilitas </h2>
        <ul>
        <li>Living Room</li>
        <li>Mini Bar</li>
        <li>smart tV</li>
        <li>Bathub</li>
        <li>Dapur Mini</li>
        <li>Meja Kerja</li>
        <li>Layanan Kamar 24 jam</li>
        <li> Wi-Fi, AC, TV, Mini-bar</li>
        <li>camilan seperti snack-snack, dan beberapa minuman soft drink yang telah tersedia secara gratis.</li>
    
    </ul>
        <p>Harga per Malam: RP 1.250.000</p>
      </div>
    </div>
  </div>

  <?php include "header.php";?>